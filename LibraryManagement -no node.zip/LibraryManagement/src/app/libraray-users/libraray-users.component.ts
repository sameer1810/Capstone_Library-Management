import { Component } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { User } from '../Models/user';
import { RestService } from '../RestServices/rest.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-libraray-users',
  standalone: true,
  imports: [NavbarComponent,CommonModule,FormsModule],
  templateUrl: './libraray-users.component.html',
  styleUrl: './libraray-users.component.css'
})
export class LibrarayUsersComponent {
    users: User[] = [];
    newUser: User = { id: 0, name: '', email: '' };
    selectedUser: User = { id: 0, name: '', email: '' };

    constructor(private userService: RestService) {}

    ngOnInit() {
        this.fetchUsers();
    }

    fetchUsers() {
        this.userService.getUsers().subscribe(
            (data) =>{ this.users = data;console.log(data)},
            (error) => console.error('Error fetching users', error)
        );
    }
    deleteUser(id: number) {
      this.userService.deleteuser(id).subscribe(
          () => {
              this.users = this.users.filter(user => user.id !== id);
          },
          (error) => console.error('Error deleting user', error),()=>{alert("user Deleted Successfully")}
      );
      
  }

  resetNewUser() {
    this.newUser = { id: 0, name: '', email: '' };
    this.selectedUser = { id: 0, name: '', email: '' };
}

updateUser(user: User) {
  this.userService.updateUser(user).subscribe(
      (updatedUser) => {
         this.ngOnInit();this.resetNewUser();
      },
      (error) => console.error('Error updating user', error),()=>{alert("user updated Successfully")}
  );
}

addUser(user:User) {
  this.userService.addUser(user).subscribe(
      (addedUser) => {
        this.ngOnInit();this.resetNewUser();
      },
      (error) => console.error('Error adding user', error),()=>{alert("user Added Successfully")}
  );
}



}
