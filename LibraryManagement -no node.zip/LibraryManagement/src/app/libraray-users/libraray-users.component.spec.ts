import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LibrarayUsersComponent } from './libraray-users.component';

describe('LibrarayUsersComponent', () => {
  let component: LibrarayUsersComponent;
  let fixture: ComponentFixture<LibrarayUsersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LibrarayUsersComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LibrarayUsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
