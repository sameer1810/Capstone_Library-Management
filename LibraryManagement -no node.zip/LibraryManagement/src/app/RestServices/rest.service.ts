import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../Models/user';
import { Observable } from 'rxjs';
import { BorrowDTO } from '../Models/borrow-dto';
import { BookDTO } from '../Models/book-dto';

@Injectable({
  providedIn: 'root'
})
export class RestService {

  constructor(private http:HttpClient) { }
  userurl="http://localhost:8082/api/users";
  bookurl="http://localhost:8181/api/Books";
  borrowurl="http://localhost:8083/borrows"

  login:boolean =false;

  userLogin(){
    return this.login;
  }

  setUserLogin(){
    this.login=true;
  }
  logoutuser(){
    this.login=false;
  }

  addUser(user:User){
    return this.http.post(`${this.userurl}`,user);
  }
  updateUser(user: User): Observable<User> {
    return this.http.put<User>(`${this.userurl}/${user.id}`, user);
}
  getUsers():Observable<User[]>{
    return this.http.get<User[]>(`${this.userurl}`)
  }

  getUserById(id:number):Observable<User>{
    return this.http.get<User>(`${this.userurl}/${id}`)
  }

  deleteuser(id:number){
    return this.http.delete(`${this.userurl}/${id}`)
  }
  //----------------------------------------------------------------------------------------------------------------------------------------------
                                      // BORROWINGS
  // -------------------------------------------------------------------------------------------------------------------------------------------------------------------- 
  
  createBorrow(borrow: BorrowDTO): Observable<BorrowDTO> {
    return this.http.post<BorrowDTO>(`${this.borrowurl}`, borrow);
  }

  getBorrowById(id: number): Observable<BorrowDTO> {
    return this.http.get<BorrowDTO>(`${this.borrowurl}/${id}`);
  }

  getAllBorrows(): Observable<BorrowDTO[]> {
    return this.http.get<BorrowDTO[]>(`${this.borrowurl}`);
  }

  updateBorrow(id: number, borrow: BorrowDTO): Observable<BorrowDTO> {
    return this.http.put<BorrowDTO>(`${this.borrowurl}/${id}`, borrow);
  }

  deleteBorrow(id: number): Observable<void> {
    return this.http.delete<void>(`${this.borrowurl}/${id}`);
  }

  markAsReturned(id: number): Observable<BorrowDTO> {
    return this.http.put<BorrowDTO>(`${this.borrowurl}/${id}/return`, {});
  }

  //----------------------------------------------------------------------------------------------------------------------------------------------
  //                                      BOOKS
  // -------------------------------------------------------------------------------------------------------------------------------------------------------------------- 


  getAllBooks(): Observable<BookDTO[]> {
    return this.http.get<BookDTO[]>(this.bookurl);
  }

  getBookById(id: number): Observable<BookDTO> {
    return this.http.get<BookDTO>(`${this.bookurl}/${id}`);
  }

  createBook(book: BookDTO): Observable<BookDTO> {
    return this.http.post<BookDTO>(this.bookurl, book);
  }

  updateBook(id: number, book: BookDTO): Observable<BookDTO> {
    return this.http.put<BookDTO>(`${this.bookurl}/${id}`, book);
  }

  deleteBook(id: number): Observable<void> {
    return this.http.delete<void>(`${this.bookurl}/${id}`);
  }

}
