import { Component } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { RouterLink } from '@angular/router';
import { RestService } from '../RestServices/rest.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [NavbarComponent,RouterLink,CommonModule,FormsModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  constructor(private service:RestService){}
  loginstatus: boolean =false;
  ngOnInit() {    
    this.loginstatus =this.service.userLogin()
    console.log(this.loginstatus)
  }
  logout(){
    this.service.logoutuser();
    this.ngOnInit();
  }
}
