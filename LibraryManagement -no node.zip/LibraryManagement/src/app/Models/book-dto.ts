export interface BookDTO {
    id: number;
    name: string;
    author: string;
    quantity: number;
}
