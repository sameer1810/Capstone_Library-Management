import { Component } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { User } from '../Models/user';
import { Router } from '@angular/router'
import { RouterModule } from '@angular/router';
import { routes } from '../app.routes';
import { RestService } from '../RestServices/rest.service';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [NavbarComponent,CommonModule,FormsModule],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent {
  constructor(private router:Router,private service:RestService){}
AdminLogin:any ={email:"admin@libraray.com",password:"admin"};
selectedUser: User = { id: 0, name: '', email: '',password:''};

UserSignup(user:User){
  console.log(user);
  if(user.email === this.AdminLogin.email && user.password == this.AdminLogin.password){
    this.service.setUserLogin();
    this.router.navigate(['/home']);
  }else{
    alert("Error Login Details ");
  }
}
}
