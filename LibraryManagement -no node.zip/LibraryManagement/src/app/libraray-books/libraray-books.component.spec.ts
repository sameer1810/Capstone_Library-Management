import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LibrarayBooksComponent } from './libraray-books.component';

describe('LibrarayBooksComponent', () => {
  let component: LibrarayBooksComponent;
  let fixture: ComponentFixture<LibrarayBooksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LibrarayBooksComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LibrarayBooksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
