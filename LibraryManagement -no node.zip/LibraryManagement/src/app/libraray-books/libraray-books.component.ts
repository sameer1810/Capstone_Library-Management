import { Component } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { RestService } from '../RestServices/rest.service';
import { BookDTO } from '../Models/book-dto';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import * as $ from 'jquery';

@Component({
  selector: 'app-libraray-books',
  standalone: true,
  imports: [NavbarComponent,CommonModule,FormsModule],
  templateUrl: './libraray-books.component.html',
  styleUrl: './libraray-books.component.css'
})
export class LibrarayBooksComponent {
  books: BookDTO[] = [];
  selectedBook: BookDTO = { id: 0, name: '', author: '', quantity: 0 }; 
  
  constructor(private bookService: RestService) {}
  ngOnInit() {
    this.loadBooks();
  }

  loadBooks() {
    this.bookService.getAllBooks().subscribe(
      (data) => {
        this.books = data;
        console.log(this.books)
      },
      (error) => {
        console.error('Error fetching books', error);
      }
    );
  }

  deleteBook(id: number) {
    this.bookService.deleteBook(id).subscribe(
      () => {
        this.books = this.books.filter(book => book.id !== id);
        
      },
      (error) => {
        console.error('Error deleting book', error);
      },()=>{alert("Deleted SuccessFully")}
    );
  }

  updateBook(book: BookDTO) {
    this.bookService.updateBook(book.id!, book).subscribe(
      (updatedBook) => {
        console.log(updatedBook);this.ngOnInit();
        
      },
      (error) => {
        console.error('Error updating book', error);
      }
    );
  }

  addBook(book: BookDTO) {
    this.bookService.createBook(book).subscribe(
        (addedBook) => {
            console.log(addedBook);this.ngOnInit();this.resetSelectedBook();
        },
        (error) => {
            console.error('Error adding book', error);
        },
        ()=>{alert("Added SuccessFully")}
    );
}
resetSelectedBook() {
  this.selectedBook = { id: 0, name: '', author: '', quantity: 0 }; // Reset to default values
}
}
