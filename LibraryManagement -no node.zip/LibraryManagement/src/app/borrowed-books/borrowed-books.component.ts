import { Component } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { BorrowDTO } from '../Models/borrow-dto';
import { RestService } from '../RestServices/rest.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-borrowed-books',
  standalone: true,
  imports: [NavbarComponent,CommonModule,FormsModule],
  templateUrl: './borrowed-books.component.html',
  styleUrl: './borrowed-books.component.css'
})
export class BorrowedBooksComponent {
  borrowedBooks: BorrowDTO[] = [];
    selectedBorrow: BorrowDTO = { id: 0, userId: 0, bookId: 0, borrowDate: new Date(), returnDate: null, returned: false };
    isModalOpen: boolean = false;
    newBorrow: BorrowDTO = { id: 0, userId: 0, bookId: 0, borrowDate: new Date(), returnDate: null, returned: false };

    constructor(private borrowService: RestService) {}

    ngOnInit() {
        this.loadBorrowedBooks();
    }

    loadBorrowedBooks() {
      this.borrowService.getAllBorrows().subscribe(
          (data) => {
              this.borrowedBooks = data;
              console.log(data)
          },
          (error) => {
              console.error('Error fetching borrowed books', error);
          }
      );
  }

  deleteBorrow(id: number) {
    this.borrowService.deleteBorrow(id).subscribe(
        () => {
            this.borrowedBooks = this.borrowedBooks.filter(borrow => borrow.id !== id);
        },
        (error) => {
            console.error('Error deleting borrow entry', error);
        },()=>{
          alert("successfully deleted");
        }
    );
}


updateBorrow(borrow: BorrowDTO) {
  this.borrowService.updateBorrow(borrow.id!, borrow).subscribe(
      (updatedBorrow) => {
        console.log(updatedBorrow);this.ngOnInit();
      },
      (error) => {
          console.error('Error updating borrow entry', error);
      },()=>{alert("Update SuccessFul");this.ngOnInit()}
  );
  // console.log(borrow)
}

addBorrow(borrow:BorrowDTO) {
  this.borrowService.createBorrow(borrow).subscribe(
      (addedBorrow) => {
          console.log(addedBorrow);this.ngOnInit();
      },
      (error) => {
          console.error('Error adding borrow entry', error);
          alert(error.message)
      }
  );
}

markAsReturned(id: number) {
  this.borrowService.markAsReturned(id).subscribe(
      (returnedBorrow) => {
          console.log(returnedBorrow);this.ngOnInit()
      },
      (error) => {
          console.error('Error marking borrow as returned', error);
      },()=>{alert("Book Return Successfull")}
  );
}

}
