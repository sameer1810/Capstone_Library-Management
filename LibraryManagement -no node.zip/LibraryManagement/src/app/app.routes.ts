import { Routes } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';
import { LibrarianComponent } from './librarian/librarian.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { LibrarayBooksComponent } from './libraray-books/libraray-books.component';
import { BorrowedBooksComponent } from './borrowed-books/borrowed-books.component';
import { LibrarayUsersComponent } from './libraray-users/libraray-users.component';

export const routes: Routes = [
    {path:"",component:SignupComponent},
    {path:"home",component:HomeComponent},
    {path:"signup",component:SignupComponent},
    {path:"librarain",component:LibrarianComponent},
    {path:"librarayBooks",component:LibrarayBooksComponent},
    {path:"BorrowedBooks",component:BorrowedBooksComponent},
    {path:"LibraryUsers",component:LibrarayUsersComponent},
    {path:"**",component:PageNotFoundComponent}
];
